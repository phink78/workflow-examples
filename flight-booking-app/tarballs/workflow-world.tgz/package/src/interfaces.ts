import type {
  CreateEventParams,
  CreateEventRequest,
  Event,
  EventResult,
  GetEventParams,
  ListEventsByCorrelationIdParams,
  ListEventsParams,
  RunCreatedEventRequest,
} from './events.js';
import type { GetHookParams, Hook, ListHooksParams } from './hooks.js';
import type { Queue } from './queue.js';
import type {
  GetWorkflowRunParams,
  ListWorkflowRunsParams,
  WorkflowRun,
  WorkflowRunWithoutData,
} from './runs.js';
import type {
  GetChunksOptions,
  PaginatedResponse,
  StreamChunksResponse,
  StreamInfoResponse,
} from './shared.js';
import type {
  GetStepParams,
  ListWorkflowRunStepsParams,
  Step,
  StepWithoutData,
} from './steps.js';

export interface Streamer {
  /**
   * Override the default flush interval (in milliseconds) for buffered stream writes.
   * Chunks are accumulated in a buffer and flushed together on this interval.
   *
   * The default is 10ms, which is appropriate for HTTP-based backends where
   * each flush is a network round-trip. For backends with sub-millisecond writes
   * (e.g., Redis, local filesystem), a lower value (or 0 for immediate flushing) reduces
   * end-to-end stream latency.
   *
   * Not supported by all worlds.
   */
  streamFlushIntervalMs?: number;

  writeToStream(
    name: string,
    runId: string,
    chunk: string | Uint8Array
  ): Promise<void>;

  /**
   * Write multiple chunks to a stream in a single operation.
   * This is an optional optimization for world implementations that can
   * batch multiple writes efficiently (e.g., single HTTP request for world-vercel).
   *
   * If not implemented, the caller should fall back to sequential writeToStream() calls.
   *
   * @param name - The stream name
   * @param runId - The run ID
   * @param chunks - Array of chunks to write, in order
   */
  writeToStreamMulti?(
    name: string,
    runId: string,
    chunks: (string | Uint8Array)[]
  ): Promise<void>;

  closeStream(name: string, runId: string): Promise<void>;
  /**
   * Read from a stream starting at the given chunk index.
   * Positive values skip that many chunks from the start (0-based).
   * Negative values start that many chunks before the current end
   * (e.g. -3 on a 10-chunk stream starts at chunk 7). Clamped to 0.
   */
  readFromStream(
    name: string,
    startIndex?: number
  ): Promise<ReadableStream<Uint8Array>>;
  listStreamsByRunId(runId: string): Promise<string[]>;

  /**
   * Fetch stream chunks with cursor-based pagination.
   *
   * Unlike `readFromStream` (which returns a live `ReadableStream` that waits
   * for new chunks in real-time), `getStreamChunks` returns a snapshot of currently
   * available chunks in a standard paginated response.
   *
   * @param name - The stream name/ID
   * @param runId - The workflow run ID that owns the stream
   * @param options - Pagination options (limit defaults to 100, max 1000)
   * @returns Paginated chunks with a `done` flag indicating stream completion
   */
  getStreamChunks(
    name: string,
    runId: string,
    options?: GetChunksOptions
  ): Promise<StreamChunksResponse>;

  /**
   * Retrieve lightweight metadata about a stream.
   *
   * Returns the tail index (index of the last known chunk, 0-based) and
   * whether the stream is complete. This is useful for resolving a negative
   * `startIndex` into an absolute position before connecting to a stream.
   *
   * @param name - The stream name/ID
   * @param runId - The workflow run ID that owns the stream
   */
  getStreamInfo(name: string, runId: string): Promise<StreamInfoResponse>;
}

/**
 * Storage interface for workflow data.
 *
 * Workflow storage models an append-only event log, so all state changes are handled through `events.create()`.
 * Run/Step/Hook entities provide materialized views into the current state, but entities can't be modified directly.
 *
 * User-originated state changes are also handled via events:
 * - run_cancelled event for run cancellation
 * - hook_disposed event for explicit hook disposal (optional)
 *
 * Note: Hooks are automatically disposed by the World implementation when a workflow
 * reaches a terminal state (run_completed, run_failed, run_cancelled). This releases
 * hook tokens for reuse by future workflows. The hook_disposed event is only needed
 * for explicit disposal before workflow completion.
 */
export interface Storage {
  runs: {
    get(
      id: string,
      params: GetWorkflowRunParams & { resolveData: 'none' }
    ): Promise<WorkflowRunWithoutData>;
    get(
      id: string,
      params?: GetWorkflowRunParams & { resolveData?: 'all' }
    ): Promise<WorkflowRun>;
    get(
      id: string,
      params?: GetWorkflowRunParams
    ): Promise<WorkflowRun | WorkflowRunWithoutData>;

    list(
      params: ListWorkflowRunsParams & { resolveData: 'none' }
    ): Promise<PaginatedResponse<WorkflowRunWithoutData>>;
    list(
      params?: ListWorkflowRunsParams & { resolveData?: 'all' }
    ): Promise<PaginatedResponse<WorkflowRun>>;
    list(
      params?: ListWorkflowRunsParams
    ): Promise<PaginatedResponse<WorkflowRun | WorkflowRunWithoutData>>;
  };

  steps: {
    get(
      runId: string | undefined,
      stepId: string,
      params: GetStepParams & { resolveData: 'none' }
    ): Promise<StepWithoutData>;
    get(
      runId: string | undefined,
      stepId: string,
      params?: GetStepParams & { resolveData?: 'all' }
    ): Promise<Step>;
    get(
      runId: string | undefined,
      stepId: string,
      params?: GetStepParams
    ): Promise<Step | StepWithoutData>;

    list(
      params: ListWorkflowRunStepsParams & { resolveData: 'none' }
    ): Promise<PaginatedResponse<StepWithoutData>>;
    list(
      params: ListWorkflowRunStepsParams & { resolveData?: 'all' }
    ): Promise<PaginatedResponse<Step>>;
    list(
      params: ListWorkflowRunStepsParams
    ): Promise<PaginatedResponse<Step | StepWithoutData>>;
  };

  events: {
    /**
     * Create a run_created event to start a new workflow run.
     * The runId may be provided by the client or left as null for the server to generate.
     *
     * @param runId - Client-generated runId, or null for server-generated
     * @param data - The run_created event data
     * @param params - Optional parameters for event creation
     * @returns Promise resolving to the created event and run entity
     */
    create(
      runId: string | null,
      data: RunCreatedEventRequest,
      params?: CreateEventParams
    ): Promise<EventResult>;

    /**
     * Create an event for an existing workflow run and atomically update the entity.
     * Returns both the event and the affected entity (run/step/hook).
     *
     * @param runId - The workflow run ID (required for all events except run_created)
     * @param data - The event to create
     * @param params - Optional parameters for event creation
     * @returns Promise resolving to the created event and affected entity
     */
    create(
      runId: string,
      data: CreateEventRequest,
      params?: CreateEventParams
    ): Promise<EventResult>;

    get(
      runId: string,
      eventId: string,
      params?: GetEventParams
    ): Promise<Event>;

    list(params: ListEventsParams): Promise<PaginatedResponse<Event>>;
    listByCorrelationId(
      params: ListEventsByCorrelationIdParams
    ): Promise<PaginatedResponse<Event>>;
  };

  hooks: {
    get(hookId: string, params?: GetHookParams): Promise<Hook>;
    getByToken(token: string, params?: GetHookParams): Promise<Hook>;
    list(params: ListHooksParams): Promise<PaginatedResponse<Hook>>;
  };
}

/**
 * The "World" interface represents how Workflows are able to communicate with the outside world.
 */
export interface World extends Queue, Storage, Streamer {
  /**
   * The highest spec version this World supports.
   *
   * When set, `start()` creates runs at this version so world-specific
   * features (e.g., CBOR queue transport) are enabled automatically.
   * When omitted, runs default to `SPEC_VERSION_SUPPORTS_EVENT_SOURCING` (2),
   * the safe baseline that all worlds — including community worlds on
   * older @workflow/world versions — are expected to handle.
   */
  specVersion?: number;

  /**
   * A function that will be called to start any background tasks needed by the World implementation.
   * For example, in the case of a queue backed World, this would start the queue processing.
   */
  start?(): Promise<void>;

  /**
   * Release any resources held by the World implementation (connection pools, listeners, etc.).
   * After calling `close()`, the World instance should not be used again.
   *
   * This is important for CLI commands and short-lived processes that need to exit cleanly
   * without relying on `process.exit()`.
   */
  close?(): Promise<void>;

  /**
   * Resolve the most recent deployment ID for the current deployment's environment.
   *
   * Used when `deploymentId: 'latest'` is passed to `start()`. The implementation
   * determines the latest deployment that shares the same environment (e.g., same
   * "production" target or same git branch for "preview" deployments) as the
   * current deployment.
   *
   * Not all World implementations support this — it is only implemented by
   * world-vercel where deployment routing is meaningful.
   */
  resolveLatestDeploymentId?(): Promise<string>;

  /**
   * Retrieve the AES-256 encryption key for a specific workflow run.
   *
   * The returned key is a ready-to-use 32-byte AES-256 key. The World
   * implementation handles all key retrieval and derivation internally
   * (e.g., HKDF from a deployment key). The core encryption module uses
   * this key directly for AES-GCM encrypt/decrypt operations.
   *
   * Two overloads:
   *
   * - `getEncryptionKeyForRun(run)` — Preferred. Pass a `WorkflowRun` when
   *   the run entity already exists. The World reads any context it needs
   *   (e.g., `deploymentId`) directly from the run.
   *
   * - `getEncryptionKeyForRun(runId, context?)` — Used only by `start()`
   *   when the run entity has not yet been created. The `context` parameter
   *   carries opaque world-specific data (e.g., `{ deploymentId }` for
   *   world-vercel) that the World needs to resolve the correct key.
   *   When `context` is omitted, the World assumes the current deployment.
   *
   * When not implemented, encryption is disabled — data is stored unencrypted.
   */
  getEncryptionKeyForRun?(run: WorkflowRun): Promise<Uint8Array | undefined>;
  getEncryptionKeyForRun?(
    runId: string,
    context?: Record<string, unknown>
  ): Promise<Uint8Array | undefined>;
}
